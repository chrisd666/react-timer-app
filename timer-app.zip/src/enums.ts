export enum StatusEnum {
  STOPPED,
  RUNNING,
  PAUSED,
}
