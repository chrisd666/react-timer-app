export interface ITime {
  hours: number;
  minutes: number;
  seconds: number;
}
